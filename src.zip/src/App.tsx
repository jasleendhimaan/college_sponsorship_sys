import React, { useEffect, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import {AppView, CampusEvent, SponsorshipApplication, Milestone, SponsorshipTier,  EventCategory,} from './types';
import {
  INITIAL_EVENTS,
} from './data/initialData';
import { supabase } from './lib/supabase';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { MobileNav } from './components/MobileNav';
import { LandingPage } from './components/LandingPage';
import { AdminDashboard } from './components/AdminDashboard';
import { OrganizerPortal } from './components/OrganizerPortal';
import { SponsorPortal } from './components/SponsorPortal';
import { CreateEventModal } from './components/CreateEventModal';
import { SponsorModal } from './components/SponsorModal';
import { EventDetailModal } from './components/EventDetailModal';
import Login from "./auth/Login";
import { useAuth } from "./context/AuthContext";
import { ToastContainer, ToastMessage,} from './components/Toast';
export default function App() {
  const { user, session, loading, signOut } = useAuth();

  // VIEW STATE
  const [currentView, setCurrentView] = useState<AppView>('landing');
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // DATA STATE
  const [events, setEvents] = useState<CampusEvent[]>([]);
  const [applications, setApplications] = useState<SponsorshipApplication[]>([]);
  const [milestones, setMilestones] = useState<Milestone[]>([]);
  const [isLoadingEvents, setIsLoadingEvents] = useState(true);

  // MODAL STATE
  const [isCreateEventOpen, setIsCreateEventOpen] = useState(false);
  const [selectedSponsorEvent, setSelectedSponsorEvent] = useState<CampusEvent | null>(null);
  const [selectedDetailEvent, setSelectedDetailEvent] = useState<CampusEvent | null>(null);

  // TOAST STATE
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // ADD TOAST
  const addToast = (
    type:
      | 'success'
      | 'info'
      | 'warning'
      | 'error',
    title: string,
    description?: string
  ) => {

    const id =
      Date.now().toString() +
      Math.random()
        .toString()
        .slice(2, 6);

    setToasts((prev) => [
      ...prev,
      {
        id,
        type,
        title,
        description,
      },
    ]);

    setTimeout(() => {

      setToasts((prev) =>
        prev.filter(
          (toast) =>
            toast.id !== id
        )
      );  }, 4000);  };

  // DISMISS TOAST
  const handleDismissToast = ( id: string) => {
   setToasts((prev) =>
      prev.filter(
        (toast) =>
          toast.id !== id ) ); };

  // HANDLE VIEW CHANGE WITH AUTHORIZATION
  const handleViewChange = (view: AppView ) => {

    // ADMIN
    if (view === 'admin') {
      if (!isAuthenticated) { addToast('warning', 'Login Required', 'Please log in to access the administrator dashboard.');
        return; }
      if (!isAdmin) {
        addToast('error', 'Access Denied', 'Only administrators can access this dashboard.');
         return;}  }

    // ORGANIZER
    if (view === 'organizer') {
      if (!isAuthenticated) {
        addToast('warning', 'Login Required', 'Please log in to access the organizer portal.');
        return; }
      if (!isOrganizer) {
        addToast('error', 'Access Denied', 'Only administrators and organizers can access the organizer portal.' );
         return;}}

    // SPONSOR
    if (view === 'sponsor') {
      if (!isAuthenticated) {addToast('warning','Login Required','Please log in to access the sponsor portal.');
        return; }
      if (!isSponsor) {
        addToast('error', 'Access Denied','Only registered sponsors can access the sponsor portal.');
        return; }  }

    setCurrentView( view ); };

  // LOAD EVENTS + SPONSORSHIP TIERS
   const loadEvents = async () => {
     try {
      setIsLoadingEvents(true);
      console.log( 'Loading events from Supabase...');

      // LOAD EVENTS
       const {
        data: eventData,
        error: eventError,
      } = await supabase
        .from('events')
        .select('*')
        .order(
          'created_at',
          {
            ascending: false,
          }
        );


      if (eventError) {

        console.error(
          'Error loading events:',
          eventError
        );

        addToast(
          'error',
          'Could not load events',
          eventError.message
        );

        setEvents(
          INITIAL_EVENTS
        );

        return;

      }


      console.log(
        'Events loaded from Supabase:',
        eventData
      );


      // ==================================================
      // LOAD SPONSORSHIP TIERS
      // ==================================================

      const {
        data: tierData,
        error: tierError,
      } = await supabase
        .from('sponsorship_tiers')
        .select('*');


      if (tierError) {

        console.error(
          'Error loading sponsorship tiers:',
          tierError
        );

        addToast(
          'warning',
          'Could not load sponsorship tiers',
          tierError.message
        );

      }


      console.log(
        'Sponsorship tiers loaded:',
        tierData
      );


      // ==================================================
      // NO EVENTS
      // ==================================================

      if (
        !eventData ||
        eventData.length === 0
      ) {

        console.log(
          'No events found in Supabase.'
        );

        setEvents(
          INITIAL_EVENTS
        );

        return;

      }


      // ==================================================
      // FORMAT EVENTS WITH SPONSORSHIP TIERS
      // ==================================================

      const formattedEvents:
        CampusEvent[] =
        eventData.map(
          (event: any) => {

            const eventTiers:
              SponsorshipTier[] =
              (tierData || [])
                .filter(
                  (tier: any) =>
                    String(
                      tier.event_id
                    ) ===
                    String(
                      event.id
                    )
                )
                .map(
                  (tier: any): SponsorshipTier => ({

                    id:
                      String(
                        tier.id
                      ),

                    name:
                      tier.name ??
                      'Sponsorship Package',

                    price:
                      Number(
                        tier.price ?? 0
                      ),

                    perks:
                      Array.isArray(
                        tier.perks
                      )
                        ? tier.perks
                        : [],

                    slotsAvailable:
                      Number(
                        tier.slots_available ?? 0
                      ),

                  })
                );


            return {

              id:
                String(
                  event.id
                ),

              title:
                event.title ??
                '',

              category:
                (
                  event.category ??
                  'Technical'
                ) as EventCategory,

              college:
                event.college ??
                '',

              location:
                event.location ??
                event.college ??
                '',

              dateRange:
                event.date_range ??
                'Upcoming Event',

              expectedReach:
                event.expected_reach ??
                '15,000+ Students',

              status:
                event.status ??
                'Preparation',

              image:
                event.image ??
                '',

              slotsRemaining:
                event.slots_remaining ??
                '4 Slots Remaining',

              description:
                event.description ??
                'Academic event looking for corporate sponsorship partners.',

              sponsorshipGoalMet:
                Number(
                  event.sponsorship_goal_met ??
                  0
                ),

              confirmedSponsorsCount:
                Number(
                  event.confirmed_sponsors_count ??
                  0
                ),

              tiers:
                eventTiers,

            };

          }
        );


      setEvents(
        formattedEvents
      );


      console.log(
        'Final formatted events with sponsorship tiers:',
        formattedEvents
      );


    } catch (error: any) {

      console.error(
        'Unexpected error loading events:',
        error
      );

      setEvents(
        INITIAL_EVENTS
      );

      addToast(
        'error',
        'Something went wrong',
        error?.message ??
        'Unable to load events.'
      );

    } finally {

      setIsLoadingEvents(
        false
      );

    }

  };


  // ==================================================
  // LOAD MILESTONES
  // ==================================================

  const loadMilestones = async () => {

    try {

      const {
        data,
        error,
      } = await supabase
        .from('milestones')
        .select('*')
        .order(
          'created_at',
          {
            ascending: true,
          }
        );


      if (error) {

        console.error(
          'Error loading milestones:',
          error
        );

        addToast(
          'error',
          'Could not load milestones',
          error.message
        );

        return;

      }


      if (
        !data ||
        data.length === 0
      ) {

        setMilestones([]);

        return;

      }


      const formattedMilestones:
        Milestone[] =
        data.map(
          (milestone: any) => ({

            id:
              String(
                milestone.id
              ),

            title:
              milestone.title ??
              '',

            description:
              milestone.description ??
              '',

            icon:
              milestone.icon ??
              '',

            iconColor:
              milestone.icon_color ??
              '',

          })
        );


      setMilestones(
        formattedMilestones
      );


    } catch (error: any) {

      console.error(
        'Unexpected milestone error:',
        error
      );

      addToast(
        'error',
        'Could not load milestones',
        error?.message ??
        'Unable to load milestones.'
      );

    }

  };


  // ==================================================
  // LOAD SPONSORSHIP APPLICATIONS
  // ==================================================

  const loadApplications = async () => {

    try {

      const {
        data,
        error,
      } = await supabase
        .from('sponsorship_applications')
        .select('*');


      if (error) {

        console.error(
          'Error loading applications:',
          error
        );

        addToast(
          'error',
          'Could not load sponsorship applications',
          error.message
        );

        return;

      }


      if (
        !data ||
        data.length === 0
      ) {

        setApplications([]);

        return;

      }


      const formattedApplications:
        SponsorshipApplication[] =
        data.map(
          (application: any) => ({

            id:
              String(
                application.id
              ),

            sponsorName:
              application.sponsor_name ??
              '',

            sponsorInitials:
              application.sponsor_initials ??
              'SP',

            eventName:
              application.event_name ??
              'Campus Event',

            eventId:
              String(
                application.event_id
              ),

            packageTier:
              application.package_tier ??
              '',

            amount:
              Number(
                application.amount ??
                0
              ),

            status:
              application.status ??
              'Pending',

            dateApplied:
              application.date_applied ??
              '',

            avatarBg:
              application.avatar_bg,

            contactEmail:
              application.contact_email ??
              '',

          })
        );


      setApplications(
        formattedApplications
      );


    } catch (error: any) {

      console.error(
        'Unexpected application error:',
        error
      );

      addToast(
        'error',
        'Could not load applications',
        error?.message ??
        'Unable to load sponsorship applications.'
      );

    }

  };


  // ==================================================
  // LOAD ALL DATA
  // ==================================================

  useEffect(() => {

    loadEvents();

    loadMilestones();

    loadApplications();

  }, []);


  // ==================================================
  // APPROVE APPLICATION
  // ==================================================

  const handleApproveApplication = async (
    appId: string
  ) => {

    if (!canManageApplications) {

      addToast(
        'error',
        'Access Denied',
        'You are not authorized to approve sponsorship applications.'
      );

      return;

    }


    const target =
      applications.find(
        (app) =>
          app.id === appId
      );


    if (!target) {
      return;
    }


    try {

      const {
        error,
      } = await supabase
        .from('sponsorship_applications')
        .update({
          status:
            'Approved',
        })
        .eq(
          'id',
          appId
        );


      if (error) {

        console.error(
          'Approval update failed:',
          error
        );

        addToast(
          'error',
          'Approval Failed',
          error.message
        );

        return;

      }


      setApplications(
        (prev) =>
          prev.map(
            (app) =>
              app.id === appId
                ? {
                    ...app,
                    status:
                      'Approved',
                  }
                : app
          )
      );


      addToast(
        'success',
        'Application Approved',
        `Proposal from ${target.sponsorName} for ${target.eventName} has been approved.`
      );


    } catch (error: any) {

      console.error(
        'Unexpected approval error:',
        error
      );

      addToast(
        'error',
        'Approval Failed',
        error?.message ??
        'Unable to approve application.'
      );

    }

  };


  // ==================================================
  // REJECT APPLICATION
  // ==================================================

  const handleRejectApplication = async (
    appId: string
  ) => {

    if (!canManageApplications) {

      addToast(
        'error',
        'Access Denied',
        'You are not authorized to reject sponsorship applications.'
      );

      return;

    }


    try {

      const target =
        applications.find(
          (app) =>
            app.id === appId
        );


      if (!target) {

        addToast(
          'error',
          'Application Not Found',
          'The selected sponsorship application could not be found.'
        );

        return;

      }


      const {
        error,
      } = await supabase
        .from('sponsorship_applications')
        .update({
          status:
            'Rejected',
        })
        .eq(
          'id',
          appId
        );


      if (error) {

        console.error(
          'Rejection update failed:',
          error
        );

        addToast(
          'error',
          'Rejection Failed',
          error.message
        );

        return;

      }


      setApplications(
        (prev) =>
          prev.map(
            (app) =>
              app.id === appId
                ? {
                    ...app,
                    status:
                      'Rejected',
                  }
                : app
          )
      );


      addToast(
        'warning',
        'Application Declined',
        `Proposal from ${target.sponsorName} was declined.`
      );


    } catch (error: any) {

      console.error(
        'Unexpected rejection error:',
        error
      );

      addToast(
        'error',
        'Rejection Failed',
        error?.message ??
        'Unable to reject application.'
      );

    }

  };


  // ==================================================
  // CREATE EVENT + SPONSORSHIP TIERS
  // ==================================================

  const handleCreateEvent = async (
    newEventData: Omit<
      CampusEvent,
      'id' |
      'sponsorshipGoalMet' |
      'confirmedSponsorsCount'
    >
  ) => {

    if (!isAuthenticated) {

      addToast(
        'warning',
        'Login Required',
        'Please log in before creating an event.'
      );

      return;

    }


    if (!canCreateEvent) {

      addToast(
        'error',
        'Access Denied',
        'Only administrators and organizers can create events.'
      );

      return;

    }


    try {

      console.log(
        'Starting event creation...'
      );


      // ==================================================
      // CREATE EVENT ID
      // ==================================================

      const eventId =
        `evt-${Date.now()}`;


      // ==================================================
      // INSERT EVENT
      // ==================================================

      const eventToInsert = {

        id:
          eventId,

        title:
          newEventData.title,

        category:
          newEventData.category,

        college:
          newEventData.college,

        location:
          newEventData.location,

        date_range:
          newEventData.dateRange,

        expected_reach:
          newEventData.expectedReach,

        status:
          newEventData.status,

        image:
          newEventData.image,

        slots_remaining:
          newEventData.slotsRemaining,

        description:
          newEventData.description,

        sponsorship_goal_met:
          15,

        confirmed_sponsors_count:
          1,

      };


      const {
        data: savedEventData,
        error: eventError,
      } = await supabase
        .from('events')
        .insert([
          eventToInsert,
        ])
        .select()
        .single();


      if (eventError) {

        console.error(
          'Event creation failed:',
          eventError
        );

        addToast(
          'error',
          'Event Creation Failed',
          eventError.message
        );

        return;

      }


      console.log(
        'Event created:',
        savedEventData
      );


      // ==================================================
      // CREATE SPONSORSHIP TIERS
      // ==================================================

      const tiersToInsert =
        (
          newEventData.tiers ||
          []
        ).map(
          (tier) => ({

            id:
              tier.id ??
              `tier-${Date.now()}-${Math.random()
                .toString(36)
                .slice(2, 8)}`,

            event_id:
              savedEventData.id,

            name:
              tier.name,

            price:
              Number(
                tier.price ?? 0
              ),

            perks:
              tier.perks,

            slots_available:
              Number(
                tier.slotsAvailable ?? 0
              ),

          })
        );


      console.log(
        'Sponsorship tiers to insert:',
        tiersToInsert
      );


      if (
        tiersToInsert.length > 0
      ) {

        const {
          error: tiersError,
        } = await supabase
          .from('sponsorship_tiers')
          .insert(
            tiersToInsert
          );


        if (tiersError) {

          console.error(
            'Tier creation failed:',
            tiersError
          );


          await supabase
            .from('events')
            .delete()
            .eq(
              'id',
              savedEventData.id
            );


          addToast(
            'error',
            'Sponsorship Tier Creation Failed',
            tiersError.message
          );

          return;

        }

      }


      // ==================================================
      // CREATE FRONTEND EVENT
      // ==================================================

      const savedEvent:
        CampusEvent = {

        id:
          String(
            savedEventData.id
          ),

        title:
          savedEventData.title,

        category:
          savedEventData.category as EventCategory,

        college:
          savedEventData.college,

        location:
          savedEventData.location,

        dateRange:
          savedEventData.date_range,

        expectedReach:
          savedEventData.expected_reach,

        status:
          savedEventData.status,

        image:
          savedEventData.image,

        slotsRemaining:
          savedEventData.slots_remaining,

        description:
          savedEventData.description,

        sponsorshipGoalMet:
          savedEventData.sponsorship_goal_met ??
          15,

        confirmedSponsorsCount:
          savedEventData.confirmed_sponsors_count ??
          1,

        tiers:
          newEventData.tiers ??
          [],

      };


      setEvents(
        (prev) => [
          savedEvent,
          ...prev,
        ]
      );


      addToast(
        'success',
        'Campus Event Published!',
        `"${savedEvent.title}" and its sponsorship packages are now live.`
      );


      setIsCreateEventOpen(
        false
      );


    } catch (error: any) {

      console.error(
        'Unexpected event creation error:',
        error
      );

      addToast(
        'error',
        'Something went wrong',
        error?.message ??
        'Unable to create the event.'
      );

    }

  };


  // ==================================================
  // SUBMIT SPONSORSHIP APPLICATION
  // ==================================================

  const handleSubmitSponsorship = async (
    eventId: string,
    sponsorName: string,
    tier: SponsorshipTier,
    email: string
  ) => {

    if (!isAuthenticated) {

      addToast(
        'warning',
        'Login Required',
        'Please log in before submitting a sponsorship proposal.'
      );

      return;

    }


    if (!isSponsor) {

      addToast(
        'error',
        'Access Denied',
        'Only registered sponsors can submit sponsorship proposals.'
      );

      return;

    }


    try {

      console.log(
        'Starting sponsorship submission...'
      );


      // ==================================================
      // FIND EVENT
      // ==================================================

      const event =
        events.find(
          (e) =>
            String(e.id) ===
            String(eventId)
        );


      if (!event) {

        addToast(
          'error',
          'Submission Failed',
          'The selected event could not be found.'
        );

        return;

      }


      // ==================================================
      // VALIDATE AMOUNT
      // ==================================================

      const sponsorshipAmount =
        Number(
          tier.price ?? 0
        );


      if (
        sponsorshipAmount <= 0
      ) {

        addToast(
          'error',
          'Invalid Sponsorship Amount',
          'The sponsorship amount entered by the organizer is not valid.'
        );

        return;

      }


      // ==================================================
      // CREATE APPLICATION ID
      // ==================================================

      const applicationId =
        `app-${Date.now()}`;


      // ==================================================
      // CREATE DATE
      // ==================================================

      const dateApplied =
        new Date()
          .toLocaleDateString(
            'en-GB',
            {
              month:
                'short',

              day:
                '2-digit',

              year:
                'numeric',
            }
          );


      // ==================================================
      // CREATE SPONSOR INITIALS
      // ==================================================

      const sponsorInitials =
        sponsorName
          .trim()
          .split(/\s+/)
          .map(
            (name) =>
              name[0]
          )
          .join('')
          .slice(
            0,
            3
          )
          .toUpperCase() ||
        'SP';


      // ==================================================
      // APPLICATION DATA
      // ==================================================

      const applicationToInsert = {

        id:
          applicationId,

        sponsor_name:
          sponsorName,

        sponsor_initials:
          sponsorInitials,

        event_name:
          event.title,

        event_id:
          event.id,

        package_tier:
          tier.name,

        amount:
          sponsorshipAmount,

        status:
          'Pending',

        date_applied:
          dateApplied,

        contact_email:
          email,

      };


      console.log(
        'Sponsorship application being sent to Supabase:',
        applicationToInsert
      );


      // ==================================================
      // INSERT APPLICATION
      // ==================================================

      const {
        data: savedApplication,
        error: applicationError,
      } = await supabase
        .from('sponsorship_applications')
        .insert([
          applicationToInsert,
        ])
        .select()
        .single();


      if (applicationError) {

        console.error(
          'Sponsorship submission failed:',
          applicationError
        );

        addToast(
          'error',
          'Sponsorship Submission Failed',
          applicationError.message
        );

        return;

      }


      if (!savedApplication) {

        addToast(
          'error',
          'Submission Failed',
          'No application data was returned from Supabase.'
        );

        return;

      }


      // ==================================================
      // CREATE FRONTEND APPLICATION
      // ==================================================

      const newApp:
        SponsorshipApplication = {

        id:
          String(
            savedApplication.id
          ),

        sponsorName:
          savedApplication.sponsor_name ??
          sponsorName,

        sponsorInitials:
          savedApplication.sponsor_initials ??
          sponsorInitials,

        eventName:
          savedApplication.event_name ??
          event.title,

        eventId:
          String(
            savedApplication.event_id ??
            event.id
          ),

        packageTier:
          savedApplication.package_tier ??
          tier.name,

        amount:
          Number(
            savedApplication.amount ??
            sponsorshipAmount
          ),

        status:
          savedApplication.status ??
          'Pending',

        dateApplied:
          savedApplication.date_applied ??
          dateApplied,

        avatarBg:
          savedApplication.avatar_bg,

        contactEmail:
          savedApplication.contact_email ??
          email,

      };


      // ==================================================
      // UPDATE APPLICATION STATE
      // ==================================================

      setApplications(
        (prev) => [
          newApp,
          ...prev,
        ]
      );


      // ==================================================
      // UPDATE EVENT SPONSORSHIP PROGRESS
      // ==================================================

      const newProgress =
        Math.min(
          100,
          event.sponsorshipGoalMet +
          10
        );


      const {
        error: progressError,
      } = await supabase
        .from('events')
        .update({
          sponsorship_goal_met:
            newProgress,
        })
        .eq(
          'id',
          event.id
        );


      if (progressError) {

        console.error(
          'Event progress update failed:',
          progressError
        );

      }


      // ==================================================
      // UPDATE EVENT FRONTEND
      // ==================================================

      setEvents(
        (prev) =>
          prev.map(
            (e) =>
              e.id === event.id
                ? {
                    ...e,

                    sponsorshipGoalMet:
                      newProgress,

                    confirmedSponsorsCount:
                      e.confirmedSponsorsCount + 1,
                  }
                : e
          )
      );


      // ==================================================
      // SUCCESS MESSAGE
      // ==================================================

      addToast(
        'success',
        'Sponsorship Submitted!',
        `Proposal for ₹${sponsorshipAmount.toLocaleString('en-IN')} (${tier.name}) sent to event organizers.`
      );


      // ==================================================
      // CLOSE SPONSOR MODAL
      // ==================================================

      setSelectedSponsorEvent(
        null
      );


    } catch (error: any) {

      console.error(
        'Unexpected sponsorship error:',
        error
      );

      addToast(
        'error',
        'Something went wrong',
        error?.message ??
        'Unable to submit sponsorship.'
      );

    }

  };


  // ==================================================
  // DOWNLOAD REPORT
  // ==================================================

  const handleDownloadReport = () => {

    if (!isAuthenticated) {

      addToast(
        'warning',
        'Login Required',
        'Please log in to download your sponsorship report.'
      );

      return;

    }


    addToast(
      'info',
      'Report Generated',
      'Sponsorship ROI impact report PDF has been downloaded.'
    );

  };


  // ==================================================
  // PENDING APPLICATION COUNT
  // ==================================================

  const pendingAppsCount =
    applications.filter(
      (app) =>
        app.status === 'Pending'
    ).length;


  // ==================================================
  // AUTH LOADING SCREEN
  // ==================================================

  if (Loading) {

    return (

      <div
        className="
          min-h-screen
          flex
          items-center
          justify-center
          bg-[#fbf8ff]
          text-[#191b24]
        "
      >

        <div
          className="
            text-center
            p-8
          "
        >

          <div
            className="
              w-10
              h-10
              border-4
              border-[#2e5bff]
              border-t-transparent
              rounded-full
              animate-spin
              mx-auto
              mb-4
            "
          />

          <p
            className="
              text-sm
              font-medium
              text-gray-600
            "
          >
            Checking authentication...
          </p>

        </div>

      </div>

    );

  }

  // RENDER
  return (
    <div
      className="
        min-h-screen
        bg-[#fbf8ff]
        text-[#191b24]
        selection:bg-[#2e5bff]
        selection:text-[#efefff]
      "
    >
      {/* TOAST */}
      <ToastContainer
        toasts={
          toasts
        }
        onDismiss={
          handleDismissToast
        }
      />
      {/* HEADER */}
      <Header
        currentView={
          currentView
        }
        onViewChange={
          handleViewChange
        }
        pendingApplicationsCount={
          pendingAppsCount
        }
        onOpenCreateEvent={() => {
          if (!isAuthenticated) {
            addToast(
              'warning',
              'Login Required',
              'Please log in to create an event.'
            );
            return; }
          if (!canCreateEvent) {
            addToast(
              'error',
              'Access Denied',
            'Only administrators and organizers can create events.'
            );
            return;
          }
          setIsCreateEventOpen(
            true
          ); }}
      />
      {/* MAIN LAYOUT */}
      <div className="flex">
        {/* SIDEBAR */}
        <Sidebar
          currentView={
            currentView
          }
          onViewChange={
            handleViewChange
          }
          activeTab={
            activeTab
          }
          setActiveTab={
            setActiveTab
          }
        />
         {/* MAIN CONTENT */}
        <main
          className={`
            flex-1
            transition-all
            ${
              currentView !==
              'landing'
                ? 'lg:pl-[260px] pb-24 lg:pb-12'
                : ''
            }          `}        >
          {/* LANDING PAGE */}
          {currentView ===
            'landing' && (
            <LandingPage
              events={
                events
              }
              onViewChange={
                handleViewChange
              }
              onOpenEventDetail={(
                evt: CampusEvent
              ) =>
                setSelectedDetailEvent(
                  evt
                )
              }
              onOpenSponsor={(
                evt: CampusEvent
              ) => {
                if (!isAuthenticated) {
                  addToast(
                    'warning',
                    'Login Required',
                    'Please log in as a sponsor to submit a sponsorship proposal.'
                  );
                  return;
                }
                if (!isSponsor) {
                  addToast(
                    'error',
                    'Access Denied',
                    'Only registered sponsors can submit sponsorship proposals.'
                  );
                  return; }
                setSelectedSponsorEvent(
                  evt
                );
              }}
              onOpenCreateEvent={() => {
                if (!isAuthenticated) {
                  addToast(
                    'warning',
                    'Login Required',
                    'Please log in to create an event.'
                  );
                  return;                }

                if (!canCreateEvent) {
                  addToast(
                    'error',
                    'Access Denied',
                    'Only administrators and organizers can create events.'
                  );
                  return;
                }
              setIsCreateEventOpen(
                  true
                );
              }}            />          )}
          {/* ADMIN DASHBOARD */}
          {currentView ===
            'admin' &&
            isAdmin && (

            <AdminDashboard
              applications={
                applications
              }

              milestones={
                milestones
              }

              onApproveApplication={
                handleApproveApplication
              }
              onRejectApplication={                handleRejectApplication}
              onOpenCreateEvent={() => {
                if (!canCreateEvent) {
                  addToast(
                    'error',
                    'Access Denied',
                    'You are not authorized to create events.'
                  );
                  return;
                }
                setIsCreateEventOpen( true);
              }}            />          )}
          {/* ORGANIZER PORTAL */}
          {currentView ===
            'organizer' &&
            isOrganizer && (
            <OrganizerPortal
              events={ events}
              applications={applications}
              onOpenCreateEvent={() => {
                if (!canCreateEvent) {
                  addToast(
                    'error',
                    'Access Denied',
                    'You are not authorized to create events.'
                  );
                    return;                }
                setIsCreateEventOpen( true  ); }}
              onApproveApplication={
                handleApproveApplication
              }
              onRejectApplication={handleRejectApplication }
              onOpenEventDetail={(evt: CampusEvent ) =>
                setSelectedDetailEvent(evt)}
            />
          )}
          {/* SPONSOR PORTAL */}
          {currentView ===
            'sponsor' &&
            isSponsor && (
            <SponsorPortal
              events={ events }
              mySponsorships={ applications}
              onOpenSponsor={(
                evt: CampusEvent
              ) =>
                setSelectedSponsorEvent( evt)  }
              onOpenEventDetail={(
                evt: CampusEvent
              ) =>
                setSelectedDetailEvent(
                  evt
                )}
              onDownloadReport={handleDownloadReport}
            /> )}
        </main>
      </div>
      {/* MOBILE NAVIGATION */}
      <MobileNav
        currentView={ currentView}
        activeTab={ activeTab  }
        setActiveTab={setActiveTab}
        pendingCount={
          pendingAppsCount
        }
      />
      {/* CREATE EVENT MODAL */}
      <CreateEventModal
        isOpen={
          isCreateEventOpen &&
          canCreateEvent
        }
        onClose={() =>
          setIsCreateEventOpen( false)}
        onCreateEvent={ handleCreateEvent }
      />
      {/* SPONSOR MODAL */}
      <SponsorModal
        event={  selectedSponsorEvent}
        isOpen={
          !!selectedSponsorEvent &&
          isSponsor }
        onClose={() =>
          setSelectedSponsorEvent(null ) }
        onSubmitSponsorship={handleSubmitSponsorship }
      />
      {/* EVENT DETAIL MODAL */}
      <EventDetailModal
        event={
          selectedDetailEvent
        }
        isOpen={
          !!selectedDetailEvent
        }
        onClose={() =>
          setSelectedDetailEvent(
            null
          )
        }
        onOpenSponsor={(
          evt: CampusEvent
        ) => {
          if (!isAuthenticated) {
            addToast(
              'warning',
              'Login Required',
              'Please log in as a sponsor to submit a sponsorship proposal.'
            );
            return;          }
          if (!isSponsor) {
            addToast(
              'error',
              'Access Denied',
              'Only registered sponsors can submit sponsorship proposals.'
            );
            return; }
          setSelectedSponsorEvent(
            evt
          );
        }}
      />
    </div>
  );
 // Show login page if user is not logged in
if (!user && currentView !== "landing") {
  return <Login />;
}
}