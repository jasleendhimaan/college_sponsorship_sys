import React, { useEffect, useState } from 'react';
import { CampusEvent, SponsorshipTier } from '../types';

interface SponsorModalProps {
  event: CampusEvent | null;
  isOpen: boolean;
  onClose: () => void;
  onSubmitSponsorship: (
    eventId: string,
    sponsorName: string,
    tier: SponsorshipTier,
    email: string
  ) => void;
}

export const SponsorModal: React.FC<SponsorModalProps> = ({
  event,
  isOpen,
  onClose,
  onSubmitSponsorship,
}) => {
  const [selectedTierId, setSelectedTierId] = useState<string>('');
  const [sponsorName, setSponsorName] = useState('TechCorp Global');
  const [email, setEmail] = useState('sponsorships@techcorp.com');

  // ==================================================
  // GET SPONSORSHIP TIERS
  // ==================================================

  const tiers: SponsorshipTier[] =
    event && Array.isArray(event.tiers)
      ? event.tiers
      : [];

  // ==================================================
  // AUTOMATICALLY SELECT FIRST TIER
  // ==================================================

  useEffect(() => {
    if (!event) {
      setSelectedTierId('');
      return;
    }

    if (
      Array.isArray(event.tiers) &&
      event.tiers.length > 0
    ) {
      // Automatically select the first sponsorship package
      setSelectedTierId(
        String(event.tiers[0].id)
      );
    } else {
      setSelectedTierId('');
    }
  }, [event]);

  // ==================================================
  // FIND SELECTED TIER
  // ==================================================

  const selectedTier =
    tiers.find(
      (tier) =>
        String(tier.id) ===
        String(selectedTierId)
    ) || null;

  // ==================================================
  // FORMAT PRICE IN INDIAN RUPEES
  // ==================================================

  const formatPrice = (
    price: number | string | null | undefined
  ) => {
    const amount = Number(price ?? 0);

    return `₹${amount.toLocaleString('en-IN')}`;
  };

  // ==================================================
  // SUBMIT SPONSORSHIP
  // ==================================================

  const handleSubmit = () => {
    if (!selectedTier) {
      alert(
        'No sponsorship package is available for this event.'
      );
      return;
    }

    if (!sponsorName.trim()) {
      alert(
        'Please enter company / sponsor name.'
      );
      return;
    }

    if (!email.trim()) {
      alert(
        'Please enter contact email.'
      );
      return;
    }

    onSubmitSponsorship(
      event!.id,
      sponsorName.trim(),
      selectedTier,
      email.trim()
    );
  };

  // ==================================================
  // CLOSE MODAL
  // ==================================================

  if (!isOpen || !event) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">

      <div className="w-full max-w-3xl bg-white rounded-2xl shadow-2xl overflow-hidden">

        {/* ========================================= */}
        {/* HEADER */}
        {/* ========================================= */}

        <div className="p-6 border-b border-slate-200">

          <div className="flex items-start justify-between">

            <div>

              <span className="inline-flex px-3 py-1 rounded-full border border-cyan-300 bg-cyan-50 text-cyan-700 text-xs font-bold uppercase tracking-wider">
                {event.category}
              </span>

              <h2 className="text-2xl font-extrabold text-slate-900 mt-2">
                Sponsor {event.title}
              </h2>

              <p className="text-sm text-slate-500">
                {event.college} • {event.dateRange}
              </p>

            </div>

            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-700 transition-colors"
              type="button"
            >
              <span className="material-symbols-outlined text-3xl">
                close
              </span>
            </button>

          </div>

        </div>


        {/* ========================================= */}
        {/* BODY */}
        {/* ========================================= */}

        <div className="p-6 space-y-6">

          {/* ======================================= */}
          {/* SPONSORSHIP TIERS */}
          {/* ======================================= */}

          <div>

            <label className="block text-sm font-bold text-slate-600 uppercase tracking-wide mb-3">
              Select Sponsorship Package Tier
            </label>


            {/* ==================================== */}
            {/* TIER LIST */}
            {/* ==================================== */}

            {tiers.length > 0 ? (

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">

                {tiers.map((tier) => {

                  const isSelected =
                    String(selectedTierId) ===
                    String(tier.id);

                  return (

                    <button
                      key={tier.id}
                      type="button"
                      onClick={() =>
                        setSelectedTierId(
                          String(tier.id)
                        )
                      }
                      className={`text-left p-4 rounded-xl border-2 transition-all ${
                        isSelected
                          ? 'border-[#0040e0] bg-blue-50 shadow-md'
                          : 'border-slate-200 bg-white hover:border-blue-300'
                      }`}
                    >

                      {/* TIER HEADER */}

                      <div className="flex items-center justify-between">

                        <h3 className="font-bold text-slate-900">
                          {tier.name}
                        </h3>

                        {isSelected && (
                          <span className="material-symbols-outlined text-[#0040e0]">
                            check_circle
                          </span>
                        )}

                      </div>


                      {/* TIER PRICE */}

                      <p className="text-2xl font-extrabold text-[#0040e0] mt-2">
                        {formatPrice(tier.price)}
                      </p>


                      {/* AVAILABLE SLOTS */}

                      <p className="text-xs text-slate-500 mt-2">
                        {tier.slotsAvailable} slots available
                      </p>


                      {/* PERKS */}

                      {tier.perks &&
                        tier.perks.length > 0 && (

                          <div className="mt-3 space-y-1">

                            {tier.perks.map(
                              (perk, index) => (

                                <p
                                  key={index}
                                  className="text-xs text-slate-600 flex gap-2"
                                >

                                  <span className="text-emerald-600">
                                    ✓
                                  </span>

                                  {perk}

                                </p>

                              )
                            )}

                          </div>

                        )}

                    </button>

                  );

                })}

              </div>

            ) : (

              /*
                We intentionally do NOT show the old
                yellow "No sponsorship packages..."
                warning here.

                If no tiers are found, the user simply
                sees this neutral message.
              */

              <div className="p-5 rounded-xl border border-slate-200 bg-slate-50 text-slate-500">

                <p className="font-semibold">
                  Sponsorship packages are currently being prepared.
                </p>

                <p className="text-sm mt-1">
                  Please contact the event organizer for sponsorship details.
                </p>

              </div>

            )}

          </div>


          {/* ========================================= */}
          {/* SPONSOR DETAILS */}
          {/* ========================================= */}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

            {/* COMPANY NAME */}

            <div>

              <label className="block text-sm font-bold text-slate-600 uppercase tracking-wide mb-2">
                Company / Sponsor Name *
              </label>

              <input
                type="text"
                value={sponsorName}
                onChange={(e) =>
                  setSponsorName(
                    e.target.value
                  )
                }
                placeholder="Enter company name"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#0040e0] focus:ring-2 focus:ring-blue-100 outline-none"
              />

            </div>


            {/* EMAIL */}

            <div>

              <label className="block text-sm font-bold text-slate-600 uppercase tracking-wide mb-2">
                Contact Email *
              </label>

              <input
                type="email"
                value={email}
                onChange={(e) =>
                  setEmail(
                    e.target.value
                  )
                }
                placeholder="Enter email"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#0040e0] focus:ring-2 focus:ring-blue-100 outline-none"
              />

            </div>

          </div>


          {/* ========================================= */}
          {/* SELECTED TIER TOTAL */}
          {/* ========================================= */}

          <div className="p-5 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between">

            <div>

              <p className="text-sm font-semibold text-slate-500">
                Selected Tier Total
              </p>


              {/* SELECTED TIER NAME */}

              {selectedTier && (
                <p className="text-sm font-semibold text-[#0040e0] mt-1">
                  {selectedTier.name}
                </p>
              )}


              {/* SELECTED TIER PRICE */}

              <p className="text-3xl font-extrabold text-slate-900 mt-1">

                {selectedTier
                  ? formatPrice(
                      selectedTier.price
                    )
                  : '₹0'}

              </p>

            </div>


            {/* VERIFICATION */}

            <div className="text-right">

              <span className="inline-flex px-3 py-1 rounded-md bg-emerald-50 border border-emerald-300 text-emerald-700 text-xs font-bold">
                Instant Verification
              </span>

              <p className="text-sm text-slate-500 mt-2">
                Directly routed to event organizers
              </p>

            </div>

          </div>

        </div>


        {/* ========================================= */}
        {/* FOOTER */}
        {/* ========================================= */}

        <div className="p-6 border-t border-slate-200 flex items-center justify-end gap-4">

          {/* CANCEL */}

          <button
            onClick={onClose}
            type="button"
            className="px-5 py-3 text-slate-600 font-bold hover:text-slate-900"
          >
            Cancel
          </button>


          {/* SUBMIT */}

          <button
            onClick={handleSubmit}
            type="button"
            disabled={!selectedTier}
            className={`px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-all ${
              selectedTier
                ? 'bg-[#0040e0] text-white hover:bg-[#2e5bff] shadow-md'
                : 'bg-slate-300 text-white cursor-not-allowed'
            }`}
          >

            <span className="material-symbols-outlined">
              handshake
            </span>

            Submit Sponsorship Proposal

          </button>

        </div>

      </div>

    </div>
  );
};