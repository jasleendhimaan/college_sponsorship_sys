import React from 'react';
import { AppView } from '../types';
import { LOGO_URL } from '../data/initialData';

interface SidebarProps {
  currentView: AppView;
  onViewChange: (view: AppView) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onViewChange,
  activeTab,
  setActiveTab
}) => {
  if (currentView === 'landing') return null;

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
    { id: 'events', label: 'Events', icon: 'calendar_today' },
    { id: 'sponsorships', label: 'Sponsorships', icon: 'payments' },
    { id: 'applications', label: 'Applications', icon: 'assignment_turned_in' },
    { id: 'reports', label: 'Reports', icon: 'bar_chart' },
    { id: 'settings', label: 'Settings', icon: 'settings' }
  ];

  return (
    <aside className="hidden lg:flex flex-col w-[260px] h-screen fixed left-0 top-0 bg-[#0040e0] border-r border-blue-800 z-50 text-white">
      {/* Sidebar Header Brand */}
      <div className="p-6 flex items-center gap-3 border-b border-white/10">
        <button
          onClick={() => onViewChange('landing')}
          className="flex items-center gap-3 hover:opacity-90 transition-opacity"
        >
          <img
            src={LOGO_URL}
            alt="PCTE Logo"
            className="w-10 h-10 rounded-lg bg-white p-1 shadow-md object-contain"
          />
          <div className="text-left">
            <span className="font-extrabold text-xl tracking-tight text-white block leading-none">
              PCTE
            </span>
            <span className="text-[10px] text-blue-200 font-semibold tracking-wider uppercase">
              Campus Bridge
            </span>
          </div>
        </button>
      </div>

      {/* Portal Role Badge */}
      <div className="px-6 py-3 bg-blue-900/50 border-b border-white/10 flex items-center justify-between text-xs font-semibold">
        <span className="text-blue-200 uppercase tracking-wider text-[10px]">Active Portal</span>
        <span className="bg-white/20 text-white px-2 py-0.5 rounded text-[11px]">
          {currentView === 'admin'
            ? 'Admin'
            : currentView === 'organizer'
            ? 'Organizer'
            : 'Sponsor'}
        </span>
      </div>

      {/* Navigation Items */}
      <nav className="mt-4 flex-1 space-y-1 px-3 overflow-y-auto no-scrollbar">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-xl font-semibold text-sm transition-all ${
                isActive
                  ? 'bg-[#00ccf9] text-[#001f28] shadow-md border-l-4 border-white'
                  : 'text-white/80 hover:bg-white/10 hover:text-white'
              }`}
            >
              <span
                className={`material-symbols-outlined text-xl ${
                  isActive ? 'filled' : ''
                }`}
              >
                {item.icon}
              </span>
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Bottom Switch Portal Helper */}
      <div className="p-4 border-t border-white/10 bg-blue-900/30">
        <p className="text-[10px] font-bold uppercase tracking-wider text-blue-200 mb-2">
          Role Navigator
        </p>
        <div className="grid grid-cols-3 gap-1">
          <button
            onClick={() => onViewChange('admin')}
            className={`py-1.5 rounded text-[11px] font-semibold transition-all ${
              currentView === 'admin' ? 'bg-white text-[#0040e0]' : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            Admin
          </button>
          <button
            onClick={() => onViewChange('organizer')}
            className={`py-1.5 rounded text-[11px] font-semibold transition-all ${
              currentView === 'organizer' ? 'bg-white text-[#0040e0]' : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            Organizer
          </button>
          <button
            onClick={() => onViewChange('sponsor')}
            className={`py-1.5 rounded text-[11px] font-semibold transition-all ${
              currentView === 'sponsor' ? 'bg-white text-[#0040e0]' : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            Sponsor
          </button>
        </div>
      </div>
    </aside>
  );
};
