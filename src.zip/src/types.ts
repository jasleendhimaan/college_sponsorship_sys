export type AppView = 'landing' | 'admin' | 'organizer' | 'sponsor';

export type EventCategory = 'Technical' | 'Cultural' | 'Sports' | 'Business' | 'Innovation';

export interface SponsorshipTier {
  id: string;
  name: string; // e.g. 'Platinum', 'Gold', 'Silver', 'Title'
  price: number;
  perks: string[];
  slotsAvailable: number;
}

export interface CampusEvent {
  id: string;
  title: string;
  category: EventCategory;
  college: string;
  location: string;
  dateRange: string;
  expectedReach: string;
  sponsorshipGoalMet: number; // percentage e.g. 82
  status: 'Ongoing' | 'Preparation' | 'Completed' | 'Upcoming';
  image: string;
  slotsRemaining: string;
  description: string;
  tiers: SponsorshipTier[];
  confirmedSponsorsCount: number;
}

export type ApplicationStatus = 'Pending' | 'Approved' | 'Rejected' | 'Paid';

export interface SponsorshipApplication {
  id: string;
  sponsorName: string;
  sponsorInitials: string;
  eventName: string;
  eventId: string;
  packageTier: string;
  amount: number;
  status: ApplicationStatus;
  dateApplied: string;
  avatarBg?: string;
  contactEmail?: string;
}

export interface Milestone {
  id: string;
  title: string;
  description: string;
  icon: string;
  iconColor: string;
}

export interface RevenueMetric {
  totalRevenue: number;
  activeEventsCount: number;
  ongoingTodayCount: number;
  pendingSponsorshipsCount: number;
  totalSponsorsCount: number;
  newSponsorsThisWeek: number;
}
