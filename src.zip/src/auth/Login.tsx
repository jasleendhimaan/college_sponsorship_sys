import { useState } from "react";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const {
    signIn,
    signUp,
    signInWithGoogle,
  } = useAuth();

  const [isLogin, setIsLogin] = useState(true);

  const [fullName, setFullName] = useState("");

  const [email, setEmail] = useState("");

  const [password, setPassword] =
    useState("");

  const [loading, setLoading] =
    useState(false);

  async function handleSubmit(
    e: React.FormEvent
  ) {
    e.preventDefault();

    setLoading(true);

    if (isLogin) {
      const { error } = await signIn(
        email,
        password
      );

      if (error) {
        alert(error.message);
      }
    } else {
      const { error } = await signUp(
        email,
        password,
        fullName
      );

      if (error) {
        alert(error.message);
      } else {
        alert(
          "Registration successful!"
        );
      }
    }

    setLoading(false);
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#5B21B6] via-[#7C3AED] to-[#A855F7]">

      <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10"></div>

      <div className="relative w-full max-w-md">

        <div className="backdrop-blur-xl bg-white/15 border border-white/20 rounded-3xl shadow-2xl p-8">

          <div className="text-center mb-8">

            <div className="w-20 h-20 rounded-full bg-white flex items-center justify-center mx-auto shadow-lg">

              <span className="text-4xl">
                🎓
              </span>

            </div>

            <h1 className="mt-5 text-3xl font-bold text-white">
              PCTE Sponsorship Portal
            </h1>

            <p className="text-purple-100 mt-2">
              Campus Sponsorship Management System
            </p>

          </div>

          <form
            onSubmit={handleSubmit}
            className="space-y-5"
          >

            {!isLogin && (

              <input
                type="text"
                placeholder="Full Name"
                className="w-full rounded-xl p-4 bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none"
                value={fullName}
                onChange={(e)=>
                  setFullName(e.target.value)
                }
              />

            )}

            <input
              type="email"
              placeholder="Email Address"
              className="w-full rounded-xl p-4 bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none"
              value={email}
              onChange={(e)=>
                setEmail(e.target.value)
              }
            />

            <input
              type="password"
              placeholder="Password"
              className="w-full rounded-xl p-4 bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none"
              value={password}
              onChange={(e)=>
                setPassword(e.target.value)
              }
            />

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-xl bg-white text-purple-700 py-4 font-bold hover:scale-105 transition"
            >

              {loading
                ? "Please wait..."
                : isLogin
                ? "Login"
                : "Create Account"}

            </button>

          </form>

          <div className="my-6 flex items-center">

            <div className="flex-1 border-t border-white/20"/>

            <span className="mx-4 text-white">
              OR
            </span>

            <div className="flex-1 border-t border-white/20"/>

          </div>

          <button
            onClick={signInWithGoogle}
            className="w-full bg-white rounded-xl py-4 font-semibold hover:scale-105 transition"
          >
            Continue with Google
          </button>

          <div className="mt-8 text-center">

            <button
              onClick={()=>
                setIsLogin(!isLogin)
              }
              className="text-white hover:underline"
            >

              {isLogin
                ? "Create New Account"
                : "Already have an account?"}

            </button>

          </div>

        </div>

      </div>

    </div>
  );
}